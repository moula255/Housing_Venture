
import './App.css';
import GridExample from './GridExample';

function App() {
  return (
    <div className="App">
      <h2>Grid Application Integration </h2>
      <GridExample />
    </div>
  );
}

export default App;
